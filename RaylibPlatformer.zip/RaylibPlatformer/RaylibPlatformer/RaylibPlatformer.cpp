#include "raylib.h"
#include <iostream>
#include <vector>

// Include header files
#include "./Scripts/Player/Player.h"
#include "./Scripts/Cutscenes/OpeningCutscene.h"
#include "./Scripts/Ship/Ship.h"
#include "./Scripts/Camera/Camera.h"
#include "./Scripts/MainHandler.h"


using namespace std;

const int screenWidth = 1800;
const int screenHeight = 800;

int main()
{
    InitWindow(screenWidth, screenHeight, "PixaPirate");
    SetTargetFPS(60);
    OpeningCutscene openingcine;
    Ship ship(screenWidth / 2, screenHeight / 2, 10, screenWidth, screenHeight);
    Player player(0, 0, 1, &ship);
    GameCamera camera;
    int rectx = 400;
    int recty = 100;
    MainHandler mainhandle(&player);
    Texture2D shiptex = LoadTexture("./images/Ship/StarterShip/StarterShipSide.png");
    mainhandle.addDrawCall(shiptex, 0, Vector2{100,100});
    player.setCoords(mainhandle.drawtxs, mainhandle.texcoords);
    //vector<Texture2D> oceantiles;
    //vector<Vector2> oceantilepos;
    //for (int y = 0; y <= 27; y++)
    //{
    //    for (int x = 0; x <= 59; x++)
    //    {
    //        oceantiles.push_back(LoadTexture("./images/Ocean/OceanTileF1.png"));
    //        oceantilepos.push_back(Vector2{ (float)x * 31.0f,(float)y * 31.0f });
    //    }
    //}
    while (!WindowShouldClose())
    {
        // Update logic
        camera.ChangePlayerPos(ship.position.x, ship.position.y);

        // Begin drawing
        BeginDrawing();
        ClearBackground(DARKBLUE);
        //for (int index = 0; index <= 1593; index++)
        //{
        //    DrawTexture(oceantiles[index], oceantilepos[index].x, oceantilepos[index].y,WHITE);
        //}
        // Draw ship
        openingcine.Draw();
        if (openingcine.playingcine == false)
        {
            mainhandle.Draw();
            player.Update();
            DrawFPS(0, 0);
            player.setCoords(mainhandle.drawtxs, mainhandle.texcoords);
        }
        EndDrawing();
    }
    //for (int i = 0; i <= 1593; i++)
    //{
    //    UnloadTexture(oceantiles[i]);
    //}
    UnloadTexture(shiptex);
    CloseWindow();
    return 0;
}
