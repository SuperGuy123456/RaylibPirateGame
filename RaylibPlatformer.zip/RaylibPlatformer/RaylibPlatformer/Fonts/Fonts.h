#pragma once
#include "raylib.h"

Font piratescript = LoadFont("pixel_pirate.ttf");