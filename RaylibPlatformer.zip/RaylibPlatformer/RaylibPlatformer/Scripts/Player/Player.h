#ifndef PLAYER_H
#define PLAYER_H
#include "raylib.h"
#include "../Ship/Ship.h"
#include <vector>
#include <iostream>

using namespace std;

class Player
{
public:

	int x;
	int y;
	int depth;

	Player(int _x, int _y, int _startdepth, Ship* _ship);
	~Player();

	void Draw();
	void Update();
	void CheckInput();
	void setCoords(vector<Texture2D> texs, vector<Vector2> vector2s);
	bool controllingship = true;
	bool canchangey = true;
private:
	void nextFrame();
	float timer = 0.0f;
	int idleindex= 0;
	/*Texture2D IdleTexs[4] = {LoadTexture("D:/C++/RaylibPlatformer/RaylibPlatformer/images/Player/Idle/idle_0.png"),
		LoadTexture("D:/C++/RaylibPlatformer/RaylibPlatformer/images/Player/Idle/idle_1.png"),
		LoadTexture("D:/C++/RaylibPlatformer/RaylibPlatformer/images/Player/Idle/idle_2.png"),
		LoadTexture("D:/C++/RaylibPlatformer/RaylibPlatformer/images/Player/Idle/idle_3.png")};*/
	Texture2D idle0 = LoadTexture("./images/Player/Idle/idle_0.png");
	Texture2D idle1 = LoadTexture("./images/Player/Idle/idle_1.png");
	Texture2D idle2 = LoadTexture("./images/Player/Idle/idle_2.png");
	Texture2D idle3 = LoadTexture("./images/Player/Idle/idle_3.png");
	Texture2D idleTexs[4] = { idle0,idle1,idle2,idle3 };

	bool rightHeld = false;
	bool leftHeld = false;
	bool upHeld = false;
	bool downHeld = false;
	
	bool onGround = false;
	int facingleft = -1;
	int screenWidth = 1800;
	int screenHeight = 800;
	Ship* ship;
	vector<Texture2D> alltexs;
	vector<Vector2> allpos;
};
#endif