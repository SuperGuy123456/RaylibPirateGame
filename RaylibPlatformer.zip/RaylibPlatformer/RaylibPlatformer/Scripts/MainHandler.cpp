#include "MainHandler.h"

MainHandler::MainHandler(Player* _player)
{
    player = _player;
}

MainHandler::~MainHandler()
{
}

void MainHandler::StartCine()
{
    OpeningCutscene openingcutscene();
}

void MainHandler::Draw()
{
    // Temporary sorted vector indices by depth
    vector<size_t> sortedIndices(drawtxs.size());
    iota(sortedIndices.begin(), sortedIndices.end(), 0);

    // Sort the indices based on the y position and the height of the textures
    sort(sortedIndices.begin(), sortedIndices.end(), [this](size_t a, size_t b) {
        return (texcoords[a].y + drawtxs[a].height) < (texcoords[b].y + drawtxs[b].height);
        });

    // Draw the textures based on sorted order
    for (size_t i : sortedIndices)
    {
        // Draw textures that are in front of the player
        if (player->y + 100 <= texcoords[i].y + drawtxs[i].height)
        {
            player->Draw();
            playerdrawn = true; // Prevent drawing the player again
        }

        // Use texcoords for drawing textures
        DrawTexture(drawtxs[i], texcoords[i].x, texcoords[i].y, WHITE);
    }

    // Draw the player if it hasn't been drawn yet
    if (!playerdrawn)
    {
        player->Draw();
    }
    playerdrawn = false;
}

void MainHandler::addDrawCall(Texture2D _texture, int texdepth, Vector2 texcoord)
{
    drawtxs.push_back(_texture);
    drawtexdepths.push_back(texdepth);
    texcoords.push_back(texcoord);
}
