#pragma once
class Flintlock
{
};

