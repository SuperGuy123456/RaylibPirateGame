#ifndef MAINHANDLER_H
#define MAINHANDLER_H
#include "Cutscenes/OpeningCutscene.h"
#include "Player/Player.h"
#include <vector>
#include <iostream>
#include <algorithm>
#include <numeric>
using namespace std;
class MainHandler
{
public:
	MainHandler(Player* _player);
	~MainHandler();
	void StartCine();
	void Draw();
	void addDrawCall(Texture2D _newtexture, int texdepth, Vector2 texcoord);
	vector<Texture2D> drawtxs;
	vector<int> drawtexdepths;
	vector<Vector2> texcoords;
private:
	Player* player;
	bool playerdrawn = false;
};

#endif